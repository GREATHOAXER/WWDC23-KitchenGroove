//
//  SwiftUIView.swift
//  
//
//  Created by Hyung Seo Han on 2023/04/19.
//

import SwiftUI
import UIKit

struct MixerView: View {
    @State var count: Int = 0
    @State var timer: Timer?
    @State var isPlayingMusic: Bool = SoundSetting.instance.isPlaying()
    @State var showingAlert: Bool = false
    
    @Binding var isSelectingUtility: Bool
    
    var body: some View {
        
        let releaseGesture = DragGesture(minimumDistance: 0)
            .onEnded { _ in
                self.timer?.invalidate()
                for i in (0..<count*10000) {
                    if (i%10000 == 0) {
                        SoundSetting.instance.decreasePitch()
                    }
                }
                self.count = 0
            }
        
        let longPressGesture = LongPressGesture(minimumDuration: 0.2)
            .onEnded { value in
                if !isPlayingMusic {
                    showingAlert = true
                } else {
                    self.timer = Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true, block: { _ in
                        if count == 10 {
                            print("maximum pitch")
                        }
                        else {
                            SoundSetting.instance.increasePitch()
                            count += 1
                        }
                        
                    })
                    print("Timer started")
                }
                
            }
        
        let combination = longPressGesture.sequenced(before: releaseGesture)
        
        GeometryReader { geometry in
            VStack (alignment: .trailing){
                Button(action: {
                    isSelectingUtility = false
                }) {
                    Image("XButton")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geometry.size.height*0.05)
                        .padding()
                }
                Spacer()
                HStack {
                    Spacer()
                    Text("Mixer")
                        .font(.system(size: 28, weight: .bold))
                    Spacer()
                    
                    Image("Mixer")
                        .resizable()
                        .scaledToFit()
                        .gesture(combination)
                        .alert(isPresented: $showingAlert, content: {
                            Alert(title: Text("Play Music First"), dismissButton: .default(Text("Confirm")))
                        })
    
                    Spacer()
                    Text("Press Mixer to\n raise the pitch")
                        .font(.system(size: 17, weight: .regular))
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: geometry.size.height/3*2, alignment: .center)
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black.opacity(0.6))
            .foregroundColor(.white)
            
        }
    }
}

struct MixerView_Previews: PreviewProvider {
    static var previews: some View {
        MixerView(isSelectingUtility: .constant(true))
    }
}
