//
//  SwiftUIView.swift
//  
//
//  Created by Hyung Seo Han on 2023/04/19.
//

import SwiftUI

struct DescriptionView: View {
    @Binding var isShowingDescription: Bool
    
    var body: some View {
        GeometryReader { geometry in
            VStack {
                VStack {
                    
                }
                DetailDescriptView(isShowingDescription: $isShowingDescription)
                .frame(width: geometry.size.width/2, height: geometry.size.height/4*3)
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .background(Color.black.opacity(0.6))
        }
        
        
    }
}

struct DescriptionView_Previews: PreviewProvider {
    static var previews: some View {
        DescriptionView(isShowingDescription: .constant(true))
    }
}

struct DetailDescriptView: View {
    @Binding var isShowingDescription: Bool
    
    var body: some View {
            VStack {
                VStack(alignment: .center) {
                    Text("Welcome to Kitchen!")
                        .font(.system(size: 20, weight: .bold))
                        .padding()
                    Spacer()
                    Text("You can handle music using kitchen utilites, such as mixer, frypan, salt bottle, and zipper bag.\n\n Feel free to enjoy on your own stage!")
                        .lineLimit(10)
                        .font(.system(size: 16, weight: .semibold))
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                Spacer()
                
                Button(action: {
                    isShowingDescription = false
                }) {
                    Text("Let's Groove")
                        .padding()
                        .font(.system(size: 17, weight: .bold))
                        .frame(width: 189)
                        .background(Color("ButtonInnerColor"))
                        .cornerRadius(30)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color("ButtonBorderColor"), lineWidth: 5)
                        )
                }
                .padding()
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            .cornerRadius(30)
    }
}
