//
//  SaltBottleView.swift
//  SoundPlayer
//
//  Created by Hyung Seo Han on 2023/04/20.
//

import SwiftUI

struct SaltBottleView: View {
    @State var showingAlert: Bool = false
    @State var isPlayingMusic: Bool = SoundSetting.instance.isPlaying()
    @Binding var isSelectingUtility: Bool
    
    var body: some View {
        GeometryReader { geometry in
            VStack (alignment: .trailing){
                Button(action: {
                    isSelectingUtility = false
                    SoundSetting.instance.salt_stop()
                }) {
                    Image("XButton")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geometry.size.height*0.05)
                        .padding()
                }
                Spacer()
                HStack {
                    Spacer()
                    Text("Salt Bottle")
                        .font(.system(size: 28, weight: .bold))
                    Spacer()
                
                    Image("SaltBottle")
                        .resizable()
                        .scaledToFit()
                        .onTapGesture {
                            if !isPlayingMusic {
                                showingAlert = true
                            } else {
                                SoundSetting.instance.play_salt()
                            }
                        }
                        .alert(isPresented: $showingAlert, content: {
                            Alert(title: Text("Play Music First"), dismissButton: .default(Text("Confirm")))
                    })

                    Spacer()
                    Text("Tap bottle to sprinkle\nsalt on the music")
                        .font(.system(size: 17, weight: .regular))
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: geometry.size.height/3*2, alignment: .center)
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black.opacity(0.6))
            .foregroundColor(.white)

        }
    }
}

struct SaltBottleView_Previews: PreviewProvider {
    static var previews: some View {
        SaltBottleView(isSelectingUtility: .constant(true))
    }
}
