//
//  SwiftUIView.swift
//  
//
//  Created by Hyung Seo Han on 2023/04/20.
//

import SwiftUI

struct ZipperBagView: View {
    @State var zipValue: Double = 0
    @State var tmpValue: Double = 0
    @State var showingAlert: Bool = false
    @State var isPlayingMusic: Bool = SoundSetting.instance.isPlaying()
    @Binding var isSelectingUtility: Bool
    
    var body: some View {
        GeometryReader { geometry in
            VStack (alignment: .trailing){
                Button(action: {
                    isSelectingUtility = false
                }) {
                    Image("XButton")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: geometry.size.height*0.05)
                        .padding()
                }
                Spacer()
                HStack {
                    Spacer()
                    Text("Zipper Bag")
                        .font(.system(size: 28, weight: .bold))
                    Spacer()
                    ZStack(alignment: .top){
                        Image("ZipperBagDetail")
                            .resizable()
                            .scaledToFit()
                        Slider(value : $zipValue, in: 0...16, step : 1)
                            .tint(Color.clear)
                            .onChange(of: zipValue, perform: { value in
                                
                                if isPlayingMusic == false {
                                    showingAlert = true
                                    zipValue = 0
                                }
                                else if value > tmpValue {
                                    SoundSetting.instance.increaseBass()
                                    tmpValue = value
                                }
                                else if value < tmpValue {
                                    SoundSetting.instance.decreaseBass()
                                    tmpValue = value
                                }
                            })
                    
                    }
                    .frame(maxWidth: geometry.size.width/3, maxHeight: geometry.size.height/3*2,alignment: .top)
                    .alert(isPresented: $showingAlert, content: {
                        Alert(title: Text("Play Music First"), dismissButton: .default(Text("Confirm")))
                    })

                    Spacer()
                    Text("Drag the Slider to\nhold the sound")
                        .font(.system(size: 17, weight: .regular))
                        .multilineTextAlignment(.center)
                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: geometry.size.height/3*2, alignment: .center)
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black.opacity(0.6))
            .foregroundColor(.white)
            .onAppear {
                zipValue = SoundSetting.instance.loadBass()
                tmpValue = zipValue
            }
        }
    }
}

struct ZipperBagView_Previews: PreviewProvider {
    static var previews: some View {
        ZipperBagView(isSelectingUtility: .constant(true))
    }
}
