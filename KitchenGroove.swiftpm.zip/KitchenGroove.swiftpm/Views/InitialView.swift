import SwiftUI
import AVKit


struct InitialView: View {
    @State private var isTapped = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                VStack {
                    Spacer()
                    Text("KITCHEN\nGROOVE")
                        .font(.system(size: 60, weight: .bold))
                        .multilineTextAlignment(.center)
                        .padding()
                    Spacer()
                    VStack {
                        Button("Tap to play"){
                            isTapped = true
                        }
                        .font(.system(size:25, weight: .bold))
                        .padding()
                    }
                    .frame(maxWidth: .infinity, maxHeight: geometry.size.height/5, alignment: .top)
                    
                }
                .frame(maxWidth :.infinity, maxHeight: .infinity)
                .background(
                    Color("InitialBackground")
                )
                
                if isTapped {
                    KitchenView()
                        .transition(.opacity.animation(.easeIn))
                }
            }
        }
    }
}


struct InitialView_Previews: PreviewProvider {
    static var previews: some View {
        InitialView()
    }
}

