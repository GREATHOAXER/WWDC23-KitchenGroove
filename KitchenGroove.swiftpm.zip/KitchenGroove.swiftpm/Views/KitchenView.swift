//
//  SwiftUIView.swift
//  
//
//  Created by Hyung Seo Han on 2023/04/19.
//

import SwiftUI

struct KitchenView: View {
    @State private var isShowingDescription = true
    @State private var isSelectingUtility = false
    @State private var utilityNumber: Int = 0
    @State private var isPause: Bool = false
    @State private var nowPlaying: String = ""
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                VStack {
                    //MARK: - Utilities
                    HStack (alignment:. bottom){
                        Button(action : {
                            isSelectingUtility = true
                            utilityNumber = 1
                        }) {
                            Image("Mixer")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width * 0.15)
                        }
                        .padding(EdgeInsets(top: 0, leading: 0, bottom: geometry.size.width * 0.019, trailing: 0))
                        
                        
                        Spacer()
                        
                        Button(action : {
                            isSelectingUtility = true
                            utilityNumber = 2
                        }) {
                            Image("Frypan")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width * 0.25)
                        }
                        .padding(EdgeInsets(top: 0, leading: geometry.size.height * 0.1, bottom: geometry.size.width * 0.04, trailing: 0))

                        Spacer()
                        
                        Button(action : {
                            isSelectingUtility = true
                            utilityNumber = 3
                        }) {
                            Image("SaltBottle")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width * 0.13)
                        }
                        .padding(EdgeInsets(top: 0, leading: geometry.size.height * 0.2, bottom: geometry.size.width * 0.021, trailing: 0))
                        
                        Spacer()
                        
                        Button(action : {
                            isSelectingUtility = true
                            utilityNumber = 4
                        }) {
                            Image("ZipperBag")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width * 0.2)
                                .padding(EdgeInsets(top: 0, leading: geometry.size.height * 0.1, bottom: geometry.size.width * 0.021, trailing: 0))
                        }
                    }
                    .padding(EdgeInsets(top: geometry.size.height * 0.165, leading: 0, bottom: 0, trailing: 0))
                    .frame(maxWidth: geometry.size.width/10*9, alignment: .bottomLeading)
                   
                    //MARK: - Song Selection
                    HStack {
                        Group {
                            Button(action: {
                                if nowPlaying == "" {
                                    SoundSetting.instance.play(selectedSong: "chill")
                                    
                                } else {
                                    SoundSetting.instance.play(selectedSong: nowPlaying)
                                }
                                
                            }) {
                                Image(systemName: "play.fill")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                            
                            Button(action: {
                                SoundSetting.instance.stop()
                            }) {
                                Image(systemName: "stop.fill")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                        }
                        .padding(.leading)
                        
                        Spacer()
                        Group {
                            Button(action: {
                                SoundSetting.instance.play(selectedSong: "chill")
                                nowPlaying = "chill"
                            }) {
                                Image(systemName: "music.note")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                            Button(action: {
                                SoundSetting.instance.play(selectedSong: "dance")
                                nowPlaying = "dance"
                            }) {
                                Image(systemName: "music.note")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                            Button(action: {
                                SoundSetting.instance.play(selectedSong: "disco")
                                nowPlaying = "disce"
                            }) {
                                Image(systemName: "music.note")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                            Button(action: {
                                SoundSetting.instance.play(selectedSong: "dubstep")
                                nowPlaying = "dubstep"
                            }) {
                                Image(systemName: "music.note")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: geometry.size.width * 0.05)
                            }
                        }
                        .padding(.trailing)
                        
                    }
                    .frame(maxWidth: .infinity, maxHeight: geometry.size.height * 0.1, alignment: .bottomTrailing)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
            }
            .ignoresSafeArea()
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
            
            
            //MARK: - Background
            .background(
                Image("Main")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea(.all)
            )
            
            if isSelectingUtility {
                switch utilityNumber {
                case 1:
                    MixerView(isSelectingUtility: $isSelectingUtility)
                case 2:
                    FrypanView(isSelectingUtility: $isSelectingUtility)
                case 3:
                    SaltBottleView(isSelectingUtility: $isSelectingUtility)
                case 4:
                    ZipperBagView(isSelectingUtility: $isSelectingUtility)
                default:
                    KitchenView()
                }
            }
            
            if isShowingDescription {
                DescriptionView(isShowingDescription: $isShowingDescription)
            }
        }
    }
}

struct KitchenView_Previews: PreviewProvider {
    static var previews: some View {
        KitchenView()
    }
}
