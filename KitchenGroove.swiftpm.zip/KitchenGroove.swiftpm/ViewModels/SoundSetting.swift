//
//  SoundSetting.swift
//  SoundPlayer
//
//  Created by Hyung Seo Han on 2023/04/13.
//

import SwiftUI
import AVFoundation

class SoundSetting : ObservableObject{
    static let instance = SoundSetting()
    
    var pauseTime: Double = 0.0
    
    let audioEngine = AVAudioEngine()
    let playerNode = AVAudioPlayerNode()
    
    
    let pitchControl = AVAudioUnitTimePitch()
    let eqNode = AVAudioUnitEQ(numberOfBands: 1)
    
    let saltShakerNode = AVAudioPlayerNode()
    let fryNode = AVAudioPlayerNode()
    
    func isPlaying() -> Bool {
        return playerNode.isPlaying
    }
    
    func play(selectedSong: String) {
        if audioEngine.isRunning {
            playerNode.stop()
            saltShakerNode.stop()
            //fryNode.stop()
            audioEngine.stop()
        }
        
        guard let url = Bundle.main.url(forResource: selectedSong, withExtension: ".mp3") else {
            return
        }
        let audioFile = try! AVAudioFile(forReading: url)
        let format = audioFile.processingFormat

        audioEngine.attach(playerNode)
        audioEngine.attach(pitchControl)
        audioEngine.attach(eqNode)
        
        audioEngine.connect(playerNode, to: pitchControl, format: format)
        audioEngine.connect(pitchControl, to: eqNode, format: format)
        audioEngine.connect(eqNode, to: audioEngine.mainMixerNode, format: format)
        
        playerNode.scheduleFile(audioFile, at: nil)

        try! audioEngine.start()
        playerNode.play()
        
        eqNode.bands[0].filterType = .lowPass
        eqNode.bands[0].frequency = 5000
        eqNode.bands[0].gain = 0
        eqNode.bands[0].bypass = false
        
        pitchControl.pitch = 0
    }
    
    func play_salt() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        guard let saltUrl = Bundle.main.url(forResource: "saltShake", withExtension: ".mp3") else {
            return
        }
        let saltAudioFile = try! AVAudioFile(forReading: saltUrl)
        let saltFormat = saltAudioFile.processingFormat
        audioEngine.attach(saltShakerNode)
        audioEngine.connect(saltShakerNode, to: audioEngine.mainMixerNode, format: saltFormat)
        saltShakerNode.scheduleFile(saltAudioFile, at: nil)
        saltShakerNode.play()
    }
    
    func play_fry() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        guard let fryUrl = Bundle.main.url(forResource: "frying", withExtension: ".mp3") else {
            return
        }
        let fryAudioFile = try! AVAudioFile(forReading: fryUrl)
        let fryFormat = fryAudioFile.processingFormat
        audioEngine.attach(fryNode)
        audioEngine.connect(fryNode, to: audioEngine.mainMixerNode, format: fryFormat)
        fryNode.scheduleFile(fryAudioFile, at: nil)
        fryNode.play()
    }
    
    func stop() {
        playerNode.stop()
    }
    
    func salt_stop() {
        saltShakerNode.stop()
    }
    
    func fry_stop() {
        fryNode.stop()
    }
    func pause() {
        playerNode.pause()
    }
    
    func continuePlay() {
        if playerNode.isPlaying {
            return
        } else {
            playerNode.play()
        }
        
    }
    
    func loadBass() -> Double{
        let stage: Int = Int(eqNode.bands[0].frequency-200)/300
        return Double(16 - stage)
    }
    
    func increaseBass() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        
        guard playerNode.isPlaying == true else {
            print("Error : playerNode is not running")
            return
        }
        //Reduce frequency for amplify bass sound
        if eqNode.bands[0].frequency - 300 <= 200 {
            eqNode.bands[0].frequency = 200
        } else {
            eqNode.bands[0].frequency -= 300
        }
        eqNode.bands[0].bypass = false
    }
    
    func decreaseBass() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        
        guard playerNode.isPlaying == true else {
            print("Error : playerNode is not running")
            return
        }
        //Increase frequency for reduce bass sound
        if eqNode.bands[0].frequency + 300 >= 5000 {
            eqNode.bands[0].frequency = 5000
        } else {
            eqNode.bands[0].frequency += 300
        }
        eqNode.bands[0].bypass = false
    }
    
    
    func increasePitch() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        
        guard playerNode.isPlaying == true else {
            print("Error : playerNode is not running")
            return
        }
        
        if pitchControl.pitch + 100 > 1100 {
            pitchControl.pitch = 1000
        } else {
            pitchControl.pitch += 100
        }
        
        print(pitchControl.pitch)
    }
    
    func decreasePitch() {
        guard audioEngine.isRunning == true else {
            print("Error : audioEngine is not running")
            return
        }
        
        guard playerNode.isPlaying == true else {
            print("Error : playerNode is not running")
            return
        }
        
        if pitchControl.pitch - 100 < -1100 {
            pitchControl.pitch = -1000
        } else {
            pitchControl.pitch -= 100
        }
        
        print(pitchControl.pitch)
    }
}
